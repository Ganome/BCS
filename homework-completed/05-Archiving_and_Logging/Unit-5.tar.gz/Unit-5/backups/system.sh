#!/bin/bash
free -h > /home/sysadmin/Projects/backups/freemem/free_mem.txt
lsof > /home/sysadmin/Projects/backups/diskuse/disk_usage.txt
ps aux > /home/sysadmin/Projects/backups/openlist/open_list.txt
df / -h > /home/sysadmin/Projects/backups/freedisk/free_disk.txt
