#!/bin/bash
 #Generate a list of times that losses occured
cat ../Player_Analysis/Roulette_Losses | awk -F- '{print $1}' > Loss_Times

#DECLARE SOME CONTROL VARIABLES
TOTAL_LOSSES=$(wc -l ../Player_Analysis/Roulette_Losses | sed 's/[^0-9]*//g')
#echo $TOTAL_LOSSES

#Command to pull out Dollar Amount ONLY
#awk -F- '{print $2}' ../Player_Analysis/Roulette_Losses | sed 's/[^0-9]*//g'

#Compare the list of Losses with the current Dealer
#this for string will use the TOTAL_LOSSES variable to read through the Roulette_Losses file one line at a time, instead of cat'ting the entire file at once.
for ((i = 1 ; i <= $TOTAL_LOSSES ; i++)); do

  LOSSES_LINE=$(head -n $i ../Player_Analysis/Roulette_Losses | tail -n 1)
  #echo $LOSSES_LINE

  LOSS_TIME=$(echo ${LOSSES_LINE:0:15})
  #echo $LOSS_TIME

  DATE_VAR=$(head -n $i ../Player_Analysis/Roulette_Losses | tail -n 1 | head -c 4) #- THIS LINE WORKS!!!
  #echo $DATE_VAR

  DAILY_LOSS=$(head -n $i ../Player_Analysis/Roulette_Losses | tail -n 1)
  DAILY_LOSS=$(echo $DAILY_LOSS | sed 's/[^0-9]*//g')
  DAILY_LOSS=$(echo ${DAILY_LOSS:10:6})
  #echo $DAILY_LOSS

  TIME_VAR=$(head -n $i ../Player_Analysis/Roulette_Losses | tail -n 1)
  TIME_VAR2=$(echo ${TIME_VAR:5:10} | tail -c 3) # JUST THE AM/PM PORTION FOR SEARCHING PURPOSES
  TIME_VAR=$(echo ${TIME_VAR:5:8})
  TIME_VAR3="${TIME_VAR} ${TIME_VAR2}"
  #echo $TIME_VAR $TIME_VAR2
  #echo $TIME_VAR
  #echo $TIME_VAR3

  LOSS_DEALER=$(grep -e "${TIME_VAR3}" ../Dealer_Analysis/$DATE_VAR* | awk -F" " '{$1=$2=$3=$4="" ; print $5 $6}')
  #echo $LOSS_DEALER

  #This echo command is the final compilation and catenation of all the variables in an easily readable sentence.
  echo "There was a loss of: $"$DAILY_LOSS" on "$DATE_VAR @ $TIME_VAR " and "$LOSS_DEALER " was dealing at the time"
done
rm Loss_Times
