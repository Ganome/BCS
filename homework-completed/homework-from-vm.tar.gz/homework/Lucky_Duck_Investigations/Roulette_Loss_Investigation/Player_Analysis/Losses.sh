#!/bin/bash

#This scipt requires a target FileName to store its data in as an argument.  Ex: ./Losses.sh Notes_Player_Analysis

#grep command to pull out all the losses from the given week
grep -i "\-" *03* | sed s/_win_loss_player_data//g | awk -F: '{print($1 ":" $2 ":" $3 ":" $4)}' | sed 's/\t//g;s/ //g' > Roulette_Losses

#command for parsing the dates and dollar amount of losses
#cat Roulette_Losses | awk '{print  $1 ":" $2 $3 " LOSS OF: " $4 ":" $5 $6 $7 $8 $9 $10 $11 $12 $13 $14}' > $1
cat Roulette_Losses | awk -F: '{print  $1 ":" $2 ":" $3 ":" $4}' > $1
wc -l Roulette_Losses >> $1

#combo command to pull clean up the output and only list Names(without spaces or tabs) and count how many games they've played
#awk -F" " '{$1=$2=$3="" ; print $0}' Roulette_Losses | sed 's/[0-9]//g;s/-$,//g;s/,/\n/g;s/ //g' | sort | uniq -c | sort >> $1
awk -F"$" '{print $2}' Roulette_Losses | sed 's/[0-9]//g;s/-$,//g;s/,/\n/g;s/ //g' | sort | uniq -c | sort >> $1
