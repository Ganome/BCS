#command to parse all the Roulette Dealers and the Day and Times they worked
grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ /:/g;s/\t/:/g' | awk -F: '{print $1 ":" $2 ":" $3 ":" $4 $5 $6 $7 $8 $9 $10 $11 $12 $13}' #$10 FirstN $11 LastN Roulette Dealer
