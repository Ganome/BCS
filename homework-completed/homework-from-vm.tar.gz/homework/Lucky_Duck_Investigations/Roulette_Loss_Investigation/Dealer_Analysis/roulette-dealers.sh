#command to parse all the Roulette Dealers and the Day and Times they worked
#grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ //g' | awk '{print $1 " " $2 " " $5 " " $6}' - this is old output, working on one below
grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ /:/g;s/\t/:/g' | awk -F: '{print $1 ":" $2 ":" $3 ":" $4 $5 $6 $7 $10 $11}' #$10 FirstN $11 LastN Roulette Dealer
