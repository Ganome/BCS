#-This script accepts two arguments:
#One for the date (four digits)
#One for the time - include : and AM/PM -=- Ex: 12:00:00AM

grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ /:/g;s/\t/:/g' | awk -F: '{print $1 ":" $2 ":" $3 ":" $4 $5 $6 $7 $10 $11}' > Roulette_Dealers

SEARCHTERM="${1}:${2}"
#echo $SEARCHTERM

grep $SEARCHTERM Roulette_Dealers

rm Roulette_Dealers
