#-This script accepts three arguments:
#One for the date (four digits)
#One for the time - include : and AM/PM -=- Ex: 12:00:00AM
#The last argument is the game to search: BlackJack:1 Roulette:2 Texas'Hold'Em:3 -=- Ex. ./dealer_finder.sh 0310 05:00:00AM 2 - would look for the Roulette dealer on 0310 @ 05AM

grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ /:/g;s/\t/:/g' | awk -F: '{print $1 ":" $2 ":" $3 ":" $4 $5 $6 $7 $8 $9 $10 $11 $12 $13}'grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ /:/g;s/\t/:/g' | awk -F: '{print $1 ":" $2 ":" $3 ":" $4 $5 $6 $7 $10 $11}' > All_Dealers

SEARCHTERM="${1}:${2}"
#echo $SEARCHTERM

grep $SEARCHTERM Roulette_Dealers

rm All_Dealers
