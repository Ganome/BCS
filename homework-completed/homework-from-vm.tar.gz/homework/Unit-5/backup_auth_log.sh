tar czf /auth_backup.tgz -g /auth_backup.snar /var/log/auth.log
