#!/bin/bash
cp ../Player_Analysis/Roulette_Losses .

#This Variable acts as a stopping point in the for statement
TOTAL_LOSSES=$(wc -l Roulette_Losses | sed 's/[^0-9]*//g')
#echo $TOTAL_LOSSES #To verify the variable is set correctly

#Generate A List of All Roulette Dealers
grep -r ":00" 031* | sed 's/_Dealer_schedule//g;s/AM/:AM:/g;s/PM/:PM:/g;s/ /:/g;s/\t/:/g' | awk -F: '{print $1 ":" $2 ":" $3 ":" $4 $5 $6 $7 $10 $11}' > Roulette_Dealers

for ((i = 1 ; i <= $TOTAL_LOSSES ; i++)); do

  LOSSES_LINE=$(head -n $i Roulette_Losses | tail -n 1) # This line read out a single line at a time from the file.  line $i, which increases every interation
  #echo $LOSSES_LINE

  #Setting DTE_VAR to a date/time in the format of "0315:12:30:00AM"
  DATE_VAR=$(head -n $i ../Player_Analysis/Roulette_Losses | tail -n 1 | head -c 15)
  #echo $DATE_VAR

  grep $DATE_VAR Roulette_Dealers >> Dealers_working_during_losses #This simple command prints out whicever dealer matches the current date string
  grep $DATE_VAR Roulette_Dealers | sed 's/[0-9]*//g;s/://g;s/PM//g;s/AM//g' >> Notes_Dealer_Analysis
done

#wc -l Notes_Dealer_Analysis | sed 's/[^0-9]*//g' >> Notes_Dealer_Analysis
sort Notes_Dealer_Analysis | uniq -c >> Notes_Dealer_Analysis
rm Roulette_Dealers Roulette_Losses
